# Weather Forecast App 🌤️

A modern, responsive weather forecast application that provides real-time weather information for any location worldwide.

## Features

- 🌍 Search weather by city name
- 🌡️ Display current temperature, humidity, and wind speed
- 🎨 Clean and intuitive user interface
- 📱 Responsive design for all devices
- ⚡ Real-time weather data

## Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)
- Weather API (OpenWeatherMap or similar)
- Capacitor (for mobile deployment)

## Installation

1. Clone the repository:

```bash
git clone https://github.com/YOUR_USERNAME/Weather_forcarst_APP.git
```

2. Navigate to the project directory:

```bash
cd Weather_forcarst_APP
```

3. Install dependencies:

```bash
npm install
```

4. Open `index.html` in your browser or use a local server:

```bash
# Using Python
python -m http.server 8000

# Using Node.js http-server
npx http-server
```

## Usage

1. Enter a city name in the search box
2. Click the search button or press Enter
3. View the current weather information for that location

## API Configuration

This app uses a weather API. Make sure to:

1. Sign up for a free API key at [OpenWeatherMap](https://openweathermap.org/api)
2. Add your API key to the `script.js` file

## Screenshots

<!-- Add screenshots of your app here -->

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is open source and available under the [MIT License](LICENSE).

## Contact

Created by [Your Name] - feel free to contact me!

---

⭐ If you like this project, please give it a star on GitHub!
