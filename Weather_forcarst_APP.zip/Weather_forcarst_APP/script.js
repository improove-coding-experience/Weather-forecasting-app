// script.js - Glassmorphism Weather App
console.log("SCRIPT LOADED");

document.getElementById("openMap").addEventListener("click", () => {
  const modal = new bootstrap.Modal(document.getElementById("indiaMapModal"));
  modal.show();

  setTimeout(initMap, 200); // load map after modal opens
});

let map;

function initMap() {
  if (map) return; // prevent duplicate map load

  map = L.map("leafletMap").setView([28.6139, 77.2090], 5); // India view

  // Free OpenStreetMap tiles
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19
  }).addTo(map);

  // Click handler
  map.on("click", async function (e) {
    const lat = e.latlng.lat;
    const lon = e.latlng.lng;

    // Use free API to convert lat → city name
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;
    const res = await fetch(url);
    const data = await res.json();

    const cityName =
      data.address.city ||
      data.address.town ||
      data.address.village ||
      data.address.state ||
      "Unknown";

    city.value = cityName;
    getweather(cityName);

    bootstrap.Modal.getInstance(document.getElementById("indiaMapModal")).hide();
  });
}


// replace this API key if needed
const API_KEY = "8ba5fb84691645a384574521252111";

// elements
const Submit = document.getElementById("Submit");
const city = document.getElementById("city");
const cityNameEl = document.getElementById("cityName");
const conditionTextEl = document.getElementById("condition_text");
const iconEl = document.getElementById("condition_icon");
const tempEl = document.getElementById("temp_c");
const humidityEl = document.getElementById("humidity");
const windEl = document.getElementById("wind_kph");
const aqiEl = document.getElementById("aqi");
const aqiStatusEl = document.getElementById("aqi_status");
const extraInfo = document.getElementById("extra_info");

// Helper: map EPA index to label + color
function epaToLabelAndColor(epa) {
  switch (epa) {
    case 1: return { label: "Good", color: "#4CAF50", textColor: "#fff" };             // green
    case 2: return { label: "Moderate", color: "#FFEB3B", textColor: "#000" };         // yellow
    case 3: return { label: "Unhealthy S.G.", color: "#FF9800", textColor: "#000" };   // orange
    case 4: return { label: "Unhealthy", color: "#F44336", textColor: "#fff" };        // red
    case 5: return { label: "Very Unhealthy", color: "#9C27B0", textColor: "#fff" };   // purple
    case 6: return { label: "Hazardous", color: "#6B0000", textColor: "#fff" };        // maroon
    default: return { label: "Unknown", color: "#bdbdbd", textColor: "#000" };
  }
}

// safely set text content
function setText(el, value, suffix = "") {
  if (!el) return;
  el.textContent = (value === null || value === undefined) ? "--" : `${value}${suffix}`;
}

// set aqi badge
function setAqi(epa) {
  const { label, color, textColor } = epaToLabelAndColor(epa);
  aqiEl.textContent = (epa === undefined || epa === null) ? "—" : epa;
  aqiEl.style.background = color;
  aqiEl.style.color = textColor;
  aqiStatusEl.textContent = label;
}

// Main fetch function - accepts optional cityName param
async function getweather(cityNameParam) {
  const cityName = (cityNameParam && cityNameParam.trim() !== "") ? cityNameParam.trim() : city.value.trim();
  if (!cityName) {
    alert("Please enter a city name");
    return;
  }

  // show loading
  cityNameEl.textContent = cityName;
  conditionTextEl.textContent = "Loading...";
  setText(tempEl, "—");
  setText(humidityEl, "—");
  setText(windEl, "—");
  setAqi(null);

  try {
    const url = `https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${encodeURIComponent(cityName)}&aqi=yes`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    // update main fields
    const c = data.current;
    const loc = data.location;

    // ⭐ FIXED WEATHER ICON LOGIC ⭐
    let iconUrl = c?.condition?.icon || "";

    if (iconUrl.startsWith("//")) {
      iconUrl = "https:" + iconUrl;
    } else if (iconUrl.startsWith("/")) {
      iconUrl = "https://cdn.weatherapi.com" + iconUrl;
    }

    if (!iconUrl) {
      iconUrl = "https://cdn-icons-png.flaticon.com/512/1146/1146869.png"; // fallback icon
    }

    iconEl.src = iconUrl;
    iconEl.alt = c?.condition?.text || "Weather icon";

    setText(tempEl, c?.temp_c ?? "—", " °C");
    setText(humidityEl, c?.humidity ?? "—", " %");
    setText(windEl, c?.wind_kph ?? "—", " kph");

    // condition text
    conditionTextEl.textContent = c?.condition?.text ?? "—";

    // AQI
    const epa = c?.air_quality?.["us-epa-index"];
    setAqi(epa);

    extraInfo.textContent = `Last updated: ${c?.last_updated ?? "—"} • Location: ${loc?.name ?? cityName}, ${loc?.region ?? ""} ${loc?.country ?? ""}`;

  } catch (err) {
    console.error("Fetch error:", err);
    conditionTextEl.textContent = "Error fetching data";
    extraInfo.textContent = `Error: ${err.message || err}`;
    setText(tempEl, "—");
    setText(humidityEl, "—");
    setText(windEl, "—");
    setAqi(null);
  }
}

// Event listeners
Submit.addEventListener("click", (e) => {
  e.preventDefault();
  getweather();
});

// Enter key search
city.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    getweather();
  }
});

// optional: load a default city on first load
document.addEventListener("DOMContentLoaded", () => {
  city.value = "Chandigarh";
  getweather("Chandigarh");
});

